package com.nttdata.EmployeeFilter;

import java.util.List;

import com.nttdata.oops.inheritance.Employee;

import java.util.ArrayList;

public class Main {
	public static void main(String[] args) {
		List<Employees> Emp=new ArrayList<Employees>();
		Emp.add(new Employees(12, "Harshi", 25000, "Blore"));
		Emp.add(new Employees(67, "Prathi", 15000, "Mysore"));
		Emp.add(new Employees(84, "Niki", 35000, "Delhi"));
		Emp.add(new Employees(53, "Bhumi", 20000, "Mumbai"));
		
		Emp.stream().filter(emp->emp.getSalary()>20000).forEach(s->System.out.println(s));
			
	    Emp.stream().map(p->{return(p.getAddress().toLowerCase());}).forEach(System.out::println);
			
		}

	

}